def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        lesser = [x for x in arr[1:] if x <= pivot]
        greater = [x for x in arr[1:] if x > pivot]
        return quick_sort(lesser) + [pivot] + quick_sort(greater)

def display_top_scores(scores, n=5):
    sorted_scores = quick_sort(scores)
    top_scores = sorted_scores[-n:][::-1]
    print("Top", n, "scores:")
    for i, score in enumerate(top_scores, start=1):
        print(f"{i}. {score}%")

if __name__ == "__main__":
    # Example: storing first-year percentage of students in an array
    first_year_percentages = [85.5, 92.3, 78.8, 89.2, 94.1, 76.5, 90.7, 88.0, 95.5, 81.2]

    # Sorting and displaying top five scores
    display_top_scores(first_year_percentages)