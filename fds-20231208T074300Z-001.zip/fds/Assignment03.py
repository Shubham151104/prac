def add_matrices(matrix1, matrix2):
    return [[matrix1[i][j] + matrix2[i][j] for j in range(len(matrix1[0]))] for i in range(len(matrix1))]

def subtract_matrices(matrix1, matrix2):
    return [[matrix1[i][j] - matrix2[i][j] for j in range(len(matrix1[0]))] for i in range(len(matrix1))]

def multiply_matrices(matrix1, matrix2):
    result = [[0 for _ in range(len(matrix2[0]))] for _ in range(len(matrix1))]

    for i in range(len(matrix1)):
        for j in range(len(matrix2[0])):
            for k in range(len(matrix2)):
                result[i][j] += matrix1[i][k] * matrix2[k][j]

    return result

def transpose_matrix(matrix):
    return [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))]

def display_matrix(matrix):
    for row in matrix:
        print(row)

if __name__ == "__main__":
    # Example matrices
    matrix1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    matrix2 = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]

    # Addition of two matrices
    result_addition = add_matrices(matrix1, matrix2)
    print("Addition of matrices:")
    display_matrix(result_addition)

    # Subtraction of two matrices
    result_subtraction = subtract_matrices(matrix1, matrix2)
    print("\nSubtraction of matrices:")
    display_matrix(result_subtraction)

    # Multiplication of two matrices
    result_multiplication = multiply_matrices(matrix1, matrix2)
    print("\nMultiplication of matrices:")
    display_matrix(result_multiplication)

    # Transpose of a matrix
    result_transpose = transpose_matrix(matrix1)
    print("\nTranspose of matrix:")
    display_matrix(result_transpose)